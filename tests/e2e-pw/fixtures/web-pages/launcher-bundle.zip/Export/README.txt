Open "OPEN ME - Launcher.html".
